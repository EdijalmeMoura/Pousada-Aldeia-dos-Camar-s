import{c as a,u as s,j as e,B as t,L as n}from"./index-Bw5UP-Ru.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=a("Compass",[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);function r(){return s("Página não encontrada — Hospedaê","A página que procura não existe ou foi movida."),e.jsxs("div",{className:"flex min-h-screen flex-col items-center justify-center gap-4 p-8 text-center",children:[e.jsx("span",{className:"flex h-20 w-20 items-center justify-center rounded-2xl bg-accent text-primary",children:e.jsx(o,{className:"h-10 w-10"})}),e.jsx("h1",{className:"text-4xl font-bold",children:"404 — Página não encontrada"}),e.jsx("p",{className:"max-w-sm text-muted-foreground",children:"Parece que esta rota se perdeu pelo caminho. Volte ao início e continue a sua viagem."}),e.jsx(t,{asChild:!0,children:e.jsx(n,{to:"/",children:"Voltar ao início"})})]})}export{r as default};
